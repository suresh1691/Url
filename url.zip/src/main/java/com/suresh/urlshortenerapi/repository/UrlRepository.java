package com.suresh.urlshortenerapi.repository;

import com.suresh.urlshortenerapi.entity.Url;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface UrlRepository extends JpaRepository<Url, Long> {

    /**
     * find all Assoc by EO object Id
     * @param id - id
     * @return List of NISDEoAssocEntity
     */
    @Query(value = "update url set count=(:count) where id=(:id)", nativeQuery = true)
    public void updateCount(@Param("id") int id,@Param("count") int count);


}
